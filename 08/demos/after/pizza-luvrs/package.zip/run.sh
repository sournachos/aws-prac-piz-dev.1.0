#!/bin/bash

echo "starting pizza-luvrs"
cd /home/ec2-user/pizza-luvrs
npm start
